---
name: Ignition Intelligence
colors:
  surface: '#131314'
  surface-dim: '#131314'
  surface-bright: '#3a393a'
  surface-container-lowest: '#0e0e0f'
  surface-container-low: '#1c1b1c'
  surface-container: '#201f20'
  surface-container-high: '#2a2a2b'
  surface-container-highest: '#353436'
  on-surface: '#e5e2e3'
  on-surface-variant: '#b9cbb9'
  inverse-surface: '#e5e2e3'
  inverse-on-surface: '#313031'
  outline: '#849585'
  outline-variant: '#3b4b3d'
  surface-tint: '#00e479'
  primary: '#f1ffef'
  on-primary: '#003919'
  primary-container: '#00ff88'
  on-primary-container: '#007139'
  inverse-primary: '#006d37'
  secondary: '#c8c6c8'
  on-secondary: '#303032'
  secondary-container: '#474649'
  on-secondary-container: '#b7b4b7'
  tertiary: '#fffaf7'
  on-tertiary: '#3d2f00'
  tertiary-container: '#ffdb79'
  on-tertiary-container: '#795f01'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#60ff99'
  primary-fixed-dim: '#00e479'
  on-primary-fixed: '#00210c'
  on-primary-fixed-variant: '#005228'
  secondary-fixed: '#e5e1e4'
  secondary-fixed-dim: '#c8c6c8'
  on-secondary-fixed: '#1b1b1d'
  on-secondary-fixed-variant: '#474649'
  tertiary-fixed: '#ffe08d'
  tertiary-fixed-dim: '#e5c364'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#584400'
  background: '#131314'
  on-background: '#e5e2e3'
  surface-variant: '#353436'
  risk-low: '#00ff88'
  risk-medium: '#ffaa00'
  risk-high: '#ff3b3b'
  border-glass: rgba(255, 255, 255, 0.08)
  surface-glass: rgba(20, 20, 22, 0.7)
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  data-lg:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 24px
  data-sm:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 18px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin: 32px
  container-max: 1440px
---

## Brand & Style

The design system is engineered for high-stakes environmental monitoring, catering to agricultural stakeholders, emergency responders, and land managers. The brand personality is authoritative, vigilant, and technically advanced. It must evoke a sense of "clinical precision" and "absolute reliability" to maintain trust in life-and-property-critical situations.

The aesthetic follows a **Modern Technical** style with heavy influences from **Glassmorphism**. To minimize cognitive load during high-stress monitoring, the interface uses a deep, "ink-pool" background strategy that allows critical alerts to pop with maximum luminosity. Visual depth is created through stacked translucent layers rather than traditional shadows, mimicking high-end mission control software.

## Colors

The palette is anchored in a true-dark foundation to maximize contrast for luminous data points. 

- **Foundation:** The `#0a0a0b` serves as the primary canvas, while `#121214` is used for raised surface containers.
- **Alert Spectrum:** A strict semantic color system is used for fire risk. 
    - **Neon Green (#00ff88):** Represents safety and "Normal" status.
    - **Amber (#ffaa00):** Signals "Caution" and increasing risk factors.
    - **Fire Red (#ff3b3b):** Denotes "Critical" risk and immediate threats.
- **Overlays:** Use semi-transparent white or primary-tinted overlays for glass effects. Surface glass should never exceed 80% opacity to ensure the "frosted" background blur remains visible.

## Typography

This design system utilizes a dual-font strategy. **Inter** is the workhorse for all UI controls, headers, and descriptions, providing a clean, accessible sans-serif experience. **JetBrains Mono** is reserved for technical data points, risk percentages, coordinates, and timestamps. This monospaced font ensures that rapidly changing numerical data does not cause layout shifts and conveys a "live feed" technical feel.

Use `label-caps` in all-caps for sidebar categories and metadata tags to distinguish them from actionable body content.

## Layout & Spacing

The layout uses a **12-column Fixed Grid** for dashboard views, centered on larger screens. For the map-centric "Risk Command" view, a **No Grid** approach is adopted where glass panels float over a full-bleed map interface.

- **Dashboard:** 24px gutters, 32px margins. Components should snap to a 4px incremental rhythm.
- **Floating Panels:** Panels should maintain a consistent 16px distance from the edges of the viewport or other panels.
- **Mobile:** Transition to a single-column stacked layout with 16px horizontal margins. Navigation should move to a bottom-docked glass bar.

## Elevation & Depth

Depth is communicated through **Tonal Stacking** and **Backdrop Blurs**.

1.  **Level 0 (Base):** `#0a0a0b` (The Map or Main Background).
2.  **Level 1 (Panels):** `surface-glass` with a 12px backdrop blur and a 1px border of `border-glass`.
3.  **Level 2 (Active States/Modals):** Increased opacity and a subtle 20% glow matching the status color (e.g., a Red glow for High Risk alerts).

Avoid drop shadows. Instead, use a "Inner Glow" or "Rim Light" effect on high-risk containers to make them appear self-illuminated, consistent with an aircraft cockpit or high-tech HUD.

## Shapes

The shape language is modern and refined. Standard UI containers (cards, panels) use a `0.5rem` (8px) radius. Larger dashboard modules use `1rem` (16px). For risk indicators and status tags, use fully pill-shaped (rounded-full) geometry to differentiate "indicators" from "containers."

## Components

- **Risk Progress Bars:** Circular gauges with a 12px stroke. Use a conical gradient for the active track (e.g., transparent to #ff3b3b). Include a pulse animation for risk levels above 80%.
- **Floating Map Controls:** Small square buttons (40x40px) with `surface-glass` backgrounds and 1px white borders at 10% opacity.
- **Status Indicators:** Use a "Glow Dot" next to the label. The dot should have a CSS animation `pulse` effect if the status is "Active Fire."
- **Dark Calendars:** Deep charcoal backgrounds with `#00ff88` for the selected date range. Use low-contrast grid lines (#ffffff10).
- **Glass Cards:** Panels with `backdrop-filter: blur(16px)` and a subtle linear gradient border from top-left (white, 15% opacity) to bottom-right (white, 0% opacity).
- **Input Fields:** Darker than the container, 1px solid border that glows with the `primary` color when focused. Use JetBrains Mono for text entry.
- **Buttons:** Primary buttons use a solid `#00ff88` with black text. Secondary buttons are ghost-style with a `border-glass` and white text.